# -*- coding: utf-8 -*-
"""
交互式 TTS 客户端 — 先认证，再合成语音

用法：服务启动后执行 python tts_client.py
"""
import requests
import sys
import os

# 密码输入：优先用 getpass 隐藏输入，不支持则回退到 input
try:
    import msvcrt

    def _secure_input(prompt="密  码: "):
        """Windows 下逐字符读取，回显 * 号。"""
        sys.stdout.write(prompt)
        sys.stdout.flush()
        chars = []
        while True:
            ch = msvcrt.getch()
            if ch in (b"\r", b"\n"):
                sys.stdout.write("\n")
                break
            elif ch == b"\x08":
                if chars:
                    chars.pop()
                    sys.stdout.write("\b \b")
            elif ch == b"\x03":
                raise KeyboardInterrupt
            else:
                chars.append(ch.decode("utf-8", errors="ignore"))
                sys.stdout.write("*")
            sys.stdout.flush()
        return "".join(chars)

    _HAS_SECURE_INPUT = True
except ImportError:
    _secure_input = input
    _HAS_SECURE_INPUT = False

BASE_URL = "http://127.0.0.1:8000"
OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))


# ============================================================
# 第一步：认证
# ============================================================
print("=" * 60)
print("🔐 认证 — 先登录才能使用 TTS 接口")
print("=" * 60)

username = ""
while not username:
    username = input("用户名: ").strip()

password = ""
while not password:
    password = _secure_input("密  码: ").strip()

print(f"\n→ 正在登录 {username} ...")
resp = requests.post(
    f"{BASE_URL}/login",
    json={"username": username, "password": password},
    timeout=10,
)

if resp.status_code == 401:
    print("❌ 登录失败：用户名或密码错误")
    sys.exit(1)
elif resp.status_code != 200:
    print(f"❌ 登录失败：{resp.json()}")
    sys.exit(1)

token = resp.json()["token"]
print(f"✅ 登录成功！Token: {token[:16]}...")
print()


def tts_synthesize(text, engine="edge", **kwargs):
    """调用 /tts 接口合成语音，返回音频字节。"""
    body = {"input": text, "engine": engine}
    body.update(kwargs)
    resp = requests.post(
        f"{BASE_URL}/tts",
        json=body,
        headers={"Authorization": f"Bearer {token}"},
        timeout=60,
    )
    if resp.status_code != 200:
        print(f"❌ 合成失败 [{resp.status_code}]: {resp.json()}")
        return None
    return resp.content


# ============================================================
# 第二步：请求接口
# ============================================================
print("=" * 60)
print("📢 TTS 合成 — 输入文字，回车生成语音")
print("   输入 q 退出，输入 e 切换引擎")
print("=" * 60)

current_engine = "edge"

while True:
    text = input("\n> ").strip()
    if not text:
        continue
    if text.lower() == "q":
        print("再见！")
        break
    if text.lower() == "e":
        if current_engine == "edge":
            current_engine = "supernatural"
        else:
            current_engine = "edge"
        print(f"→ 已切换到 {current_engine} 引擎")
        continue

    audio = tts_synthesize(text, engine=current_engine)
    if audio:
        filename = f"output_{current_engine}.mp3"
        filepath = os.path.join(OUTPUT_DIR, filename)
        with open(filepath, "wb") as f:
            f.write(audio)
        print(f"✅ 已保存: {filename} ({len(audio)} bytes)")
