"""
================================================================================
TeleAI TTS 统一 HTTP 接口 (app.py)
================================================================================
整个项目只有一个文件，包含：配置 → 数据模型 → 上游签名 → 双引擎合成 → 认证 → API 路由

启动：uvicorn app:app --host 0.0.0.0 --port 8000
文档：http://127.0.0.1:8000/docs
================================================================================
"""

# ============================================================================
# 一、导入依赖
# ============================================================================
import asyncio          # 运行 edge-tts 的异步流
import base64           # 解码上游返回的 Base64 音频
import hashlib          # HMAC-SHA256 签名
import hmac
import io               # 内存文件对象，不写磁盘
import logging
import os               # 读取环境变量
import secrets          # 安全对比密码、生成随机 token
import sys              # 认证失败时退出进程
import time             # 生成时间戳
import urllib.parse     # URL 编码
import uuid             # 生成请求追踪 ID
from typing import Any, Dict, Optional, Tuple

import edge_tts                              # 微软 Edge 免费 TTS
import requests                              # 调用上游 TeleAI HTTP API
from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, StreamingResponse  # StreamingResponse = 内存流返回，不写磁盘
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer  # Bearer Token 认证
from pydantic import BaseModel, Field, validator                     # 请求体校验

from SignUtils import (                      # 你的 AppID / Secret Key 密钥常量
    EXPIRATION_IN_SECONDS,                   # 签名有效期（12 小时）
    PUBLIC_NETWORK_SING_HEADER,              # 公网鉴权头部标识
    REGION,                                  # 区域
    SIGNED_HEADERS,                          # 参与签名的请求头
    X_APP_ID,                                # 应用 ID
    X_APP_KEY,                               # 应用密钥
)

logger = logging.getLogger(__name__)


# ============================================================================
# 二、全局配置（可通过环境变量覆盖）
# ============================================================================

# -- 调用方认证（服务启动时和 /login 接口使用） --
# 服务端默认用户名密码，可通过环境变量覆盖：
#   set TTS_USERNAME=xxx
#   set TTS_PASSWORD=xxx
BASIC_USERNAME = os.getenv("TTS_USERNAME", "admin").strip()
BASIC_PASSWORD = os.getenv("TTS_PASSWORD", "tts123456").strip()

# -- 上游请求超时和 HTTPS 证书校验 --
REQUEST_TIMEOUT_SECONDS = float(os.getenv("TTS_REQUEST_TIMEOUT", "120"))  # 默认 120 秒
VERIFY_TLS = os.getenv("TTS_VERIFY_TLS", "false").strip().lower() in {
    "1", "true", "yes", "on",
}  # 默认关闭证书校验（内网环境）

# -- TTS 引擎列表（引擎名 → 上游 URL） --
# edge 引擎走本地 edge-tts 库，不走网络，所以 URL 为空
TTS_ENGINES: Dict[str, str] = {
    "supernatural": "https://openapi.teleagi.cn:443/aipaas/voice/v1/tts/supernatural",
    "realtime":     "https://openapi.teleagi.cn:443/aipaas/voice/v1/tts/supernatural",
    "offline":      "https://openapi.teleagi.cn:443/aipaas/voice/v1/tts/offLineSynthesis",
    "edge":         "",  # 本地 edge-tts，不走上游 API
}

SUPPORTED_FORMATS = {"WAV", "MP3", "FLAC"}

# -- FastAPI 应用实例 --
app = FastAPI(
    title="TeleAI Unified TTS API",
    version="1.0.0",
    description="Unified FastAPI HTTP interface for TeleAI TTS engines.",
)


# ============================================================================
# 三、Pydantic 数据模型（请求体 / 响应体）
# ============================================================================

class TTSRequest(BaseModel):
    """POST /tts 请求体。所有引擎共用同一套参数。"""
    input: str = Field(..., min_length=1, description="要转换的文本内容（必填）")
    voice: str = Field("zh-CN-XiaoxiaoNeural", min_length=1, description="语音角色")
    format: str = Field("MP3", description="音频格式（统一 MP3 输出）")
    engine: str = Field(
        "supernatural",
        description="TTS 引擎：supernatural / realtime / offline / edge",
    )
    req_id: Optional[str] = Field(
        None,
        description="请求追踪 ID，不传则自动生成 UUID",
    )
    extra_params: Dict[str, Any] = Field(
        default_factory=dict,
        description="透传给上游 TeleAI 的额外参数（Edge 引擎忽略）",
    )
    # --- 以下为 Edge TTS 专用参数 ---
    speed: float = Field(1.0, ge=0.5, le=2.0, description="语速 (0.5-2.0)")
    pitch: str = Field("0", description="音调 (-50 到 50)")
    style: str = Field("general", description="语音风格，如 cheerful/sad/angry")
    volume: str = Field("0", description="音量 (-50 到 50)")

    @validator("format")
    def normalize_format(cls, value: str) -> str:
        """校验并标准化音频格式。"""
        audio_format = value.strip().upper()
        if audio_format not in SUPPORTED_FORMATS:
            raise ValueError(f"format must be one of: {', '.join(sorted(SUPPORTED_FORMATS))}")
        return audio_format

    @validator("engine")
    def normalize_engine(cls, value: str) -> str:
        """校验并标准化引擎名称。"""
        engine = value.strip().lower()
        if engine not in TTS_ENGINES:
            raise ValueError(f"engine must be one of: {', '.join(sorted(TTS_ENGINES))}")
        return engine


class ErrorResponse(BaseModel):
    """统一错误响应格式。"""
    code: int = Field(..., description="业务错误码")
    message: str = Field(..., description="错误描述")
    details: Any = Field(None, description="错误详情")


class EngineInfo(BaseModel):
    """引擎信息（/tts/engines 接口返回）。"""
    name: str
    upstream_path: str


class LoginRequest(BaseModel):
    """POST /login 请求体。"""
    username: str
    password: str


class LoginResponse(BaseModel):
    """POST /login 响应体。"""
    token: str
    token_type: str = "bearer"


# ============================================================================
# 四、工具函数
# ============================================================================

def error_body(code: int, message: str, details: Any = None) -> Dict[str, Any]:
    """构建统一的错误 JSON 结构。"""
    return {"code": code, "message": message, "details": details}


def media_type_for(audio_format: str) -> Tuple[str, str]:
    """根据格式字符串返回 HTTP Content-Type 和文件扩展名。"""
    value = audio_format.strip().lower()
    if value == "mp3":
        return "audio/mpeg", "mp3"
    if value == "wav":
        return "audio/wav", "wav"
    if value == "flac":
        return "audio/flac", "flac"
    return "application/octet-stream", value or "bin"


# ============================================================================
# 五、异常处理器（把 FastAPI 原生异常转成统一 JSON 格式）
# ============================================================================

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    """把业务代码中主动抛出的 HTTPException 转成统一格式。"""
    detail = exc.detail
    if isinstance(detail, dict) and {"code", "message"}.issubset(detail):
        body = error_body(
            int(detail["code"]),
            str(detail["message"]),
            detail.get("details"),
        )
    else:
        body = error_body(exc.status_code * 100, str(detail))
    return JSONResponse(status_code=exc.status_code, content=body)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(
    request: Request, exc: RequestValidationError
) -> JSONResponse:
    """把 Pydantic 参数校验失败转成统一格式（状态码 422）。"""
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content=error_body(42200, "Invalid request body.", exc.errors()),
    )


# ============================================================================
# 六、上游 TeleAI 认证签名（HMAC-SHA256）
# ============================================================================
# 每次调 TeleAI API 时自动生成签名，不需要手动处理。
# 签名公式：
#   signing_key = HMAC-SHA256(AppKey, header/appid/region/timestamp/expiration)
#   signature   = HMAC-SHA256(signing_key, "POST\n/canonical/uri\n\ncanonical_headers")
#   Authorization = header/appid/region/timestamp/expiration/signed_headers/signature

def normalize(value: str, encoding_slash: bool = True) -> str:
    """URL 编码，保留安全和分隔字符。"""
    safe_chars = "~()*!'/" if encoding_slash else "~()*!'"
    return urllib.parse.quote(value, safe=safe_chars)


def generate_canonical_uri(url: str) -> str:
    """从完整 URL 中提取并编码路径部分。"""
    parsed_url = urllib.parse.urlparse(url)
    return "/".join(normalize(segment, False) for segment in parsed_url.path.split("/"))


def generate_authorization(
    url: str, method: str = "POST", canonical_query_string: str = ""
) -> str:
    """
    生成 TeleAI 上游接口的 Authorization 签名字符串。

    步骤：
    1. 用 AppKey 对签名密钥串做 HMAC-SHA256 → signing_key
    2. 用 signing_key 对规范请求串做 HMAC-SHA256 → signature
    3. 拼接最终的 Authorization 头值
    """
    timestamp = str(int(time.time()))
    canonical_uri = generate_canonical_uri(url)
    canonical_headers = f"x-app-id:{urllib.parse.quote(X_APP_ID.strip(), safe='')}"
    signed_headers = ";".join(sorted(set(SIGNED_HEADERS.split(";"))))

    # 步骤 1：生成签名密钥
    signing_key_str = (
        f"{PUBLIC_NETWORK_SING_HEADER}/{X_APP_ID}/{REGION}/"
        f"{timestamp}/{EXPIRATION_IN_SECONDS}"
    )
    signing_key = hmac.new(
        X_APP_KEY.encode("utf-8"),
        signing_key_str.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

    # 步骤 2：生成签名
    canonical_request = (
        f"{method.upper()}\n{canonical_uri}\n"
        f"{canonical_query_string}\n{canonical_headers}"
    )
    signature = hmac.new(
        signing_key.encode("utf-8"),
        canonical_request.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

    # 步骤 3：拼接
    return f"{signing_key_str}/{signed_headers}/{signature}"


def build_headers(tts_url: str) -> Dict[str, str]:
    """构建发送给上游 TeleAI 的 HTTP 请求头（含签名）。"""
    return {
        "Content-Type": "application/json",
        "X-APP-ID": X_APP_ID,
        "Authorization": generate_authorization(tts_url),
    }


def build_upstream_payload(payload: TTSRequest, req_id: str) -> Dict[str, Any]:
    """把客户端请求体转成上游 TeleAI 需要的格式。"""
    request_data: Dict[str, Any] = {
        "timestamp": int(time.time()),
        "req_id": req_id,
        "text": payload.input,         # 客户端的 "input" 映射为上游的 "text"
        "format": "MP3",               # 强制 MP3，统一输出格式
        "voice": payload.voice,
    }
    # 合并客户端透传的额外参数
    request_data.update(payload.extra_params)
    return request_data


# ============================================================================
# 七、TTS 引擎 — 远端 TeleAI 合成
# ============================================================================

def request_tts(payload: TTSRequest) -> Tuple[bytes, str, str]:
    """
    调上游 TeleAI API 合成语音。

    流程：
    1. 生成签名 → 2. POST 请求 → 3. 提取 result.audio(Base64)
    → 4. Base64 解码 → 5. 返回音频字节

    返回：(音频字节, 音频格式, 请求ID)
    """
    tts_url = TTS_ENGINES[payload.engine]
    req_id = payload.req_id or uuid.uuid4().hex
    request_data = build_upstream_payload(payload, req_id)

    # --- 发起 HTTP 请求 ---
    try:
        response = requests.post(
            tts_url,
            json=request_data,
            headers=build_headers(tts_url),
            timeout=REQUEST_TIMEOUT_SECONDS,
            verify=VERIFY_TLS,
        )
    except requests.RequestException as exc:
        logger.exception("TTS upstream request failed")
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=error_body(50201, "TTS upstream request failed.", str(exc)),
        ) from exc

    # --- 检查上游 HTTP 状态 ---
    if response.status_code != status.HTTP_200_OK:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=error_body(
                50202,
                "TTS upstream returned non-200 status.",
                {"status_code": response.status_code, "body": response.text[:1000]},
            ),
        )

    # --- 提取并解码 Base64 音频 ---
    try:
        response_data = response.json()
        audio_base64 = response_data["result"]["audio"]  # 上游返回的音频是 Base64 字符串
        audio_bytes = base64.b64decode(audio_base64)      # 解码为二进制
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=error_body(
                50203,
                "TTS upstream response does not contain valid result.audio.",
                {"body": response.text[:1000]},
            ),
        ) from exc

    if not audio_bytes:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=error_body(50204, "TTS upstream returned empty audio."),
        )

    return audio_bytes, "mp3", req_id


# ============================================================================
# 八、TTS 引擎 — 本地 Edge TTS 合成
# ============================================================================

def _format_hz(value: str) -> str:
    """确保 pitch 值以 + 或 - 开头并以 Hz 结尾，如 "+10Hz"。"""
    value = value.strip()
    if not value.endswith("Hz"):
        value = f"{value}Hz"
    if value[0] not in ("+", "-"):
        value = f"+{value}"
    return value


def _format_pct(value: str) -> str:
    """确保 volume 值以 + 或 - 开头并以 % 结尾，如 "+20%"。"""
    value = value.strip()
    if not value.endswith("%"):
        value = f"{value}%"
    if value[0] not in ("+", "-"):
        value = f"+{value}"
    return value


def _speed_to_rate(speed: float) -> str:
    """把语速倍数 (0.5-2.0) 转成 edge-tts 的百分比格式，如 "+30%"。"""
    pct = round((speed - 1.0) * 100)
    if pct >= 0:
        return f"+{pct}%"
    return f"{pct}%"


def request_edge_tts(payload: "TTSRequest") -> Tuple[bytes, str, str]:
    """
    使用 edge-tts 库本地合成语音（免费，不走网络）。

    流程：
    1. 参数转换（speed→rate, pitch→"+xxHz", volume→"+xx%"）
    2. 有情感风格时用 SSML 标记语言，无风格时传纯文本
    3. 调 edge_tts.Communicate 流式合成
    4. 收集所有音频块 → 返回完整字节

    返回：(音频字节, "mp3", 请求ID)
    """
    req_id = payload.req_id or uuid.uuid4().hex
    voice = payload.voice
    rate = _speed_to_rate(payload.speed)
    pitch = _format_hz(payload.pitch)
    volume = _format_pct(payload.volume)

    # --- 构建合成文本：有风格用 SSML，无风格用纯文本 ---
    use_style = payload.style.strip().lower() != "general"
    if use_style:
        # SSML = Speech Synthesis Markup Language，可以控制情感、语速、音调
        ssml = (
            f'<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis"'
            f' xmlns:mstts="http://www.w3.org/2001/mstts" xml:lang="zh-CN">'
            f'<voice name="{voice}">'
            f'<mstts:express-as style="{payload.style}">'
            f'<prosody rate="{rate}" pitch="{pitch}" volume="{volume}">'
            f"{payload.input}"
            f"</prosody>"
            f"</mstts:express-as>"
            f"</voice>"
            f"</speak>"
        )
        text = ssml
    else:
        text = payload.input

    # --- edge-tts 是异步库，用 asyncio.run() 驱动 ---
    async def _stream():
        communicate = edge_tts.Communicate(
            text=text,
            voice=voice,
            rate=rate,
            pitch=pitch,
            volume=volume,
        )
        audio_bytes = b""
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":        # 只收集音频帧，跳过 WordBoundary 等
                audio_bytes += chunk["data"]
        return audio_bytes

    try:
        audio_bytes = asyncio.run(_stream())
    except Exception as exc:
        logger.exception("Edge TTS synthesis failed")
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=error_body(50210, "Edge TTS synthesis failed.", str(exc)),
        ) from exc

    if not audio_bytes:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=error_body(50211, "Edge TTS returned empty audio."),
        )

    # edge-tts 只出 MP3，返回 "mp3" 确保 Content-Type 正确
    return audio_bytes, "mp3", req_id


# ============================================================================
# 九、认证系统（Bearer Token + 启动认证）
# ============================================================================

# Token 在内存中存储，服务重启后全部清空
_tokens: Dict[str, str] = {}            # token → username 的映射表

security = HTTPBearer()                  # FastAPI Bearer Token 认证方案


def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)) -> None:
    """
    拦截 /tts 请求，校验 Authorization: Bearer <token> 是否有效。
    作为 FastAPI 依赖注入到 /tts 端点中，每次请求自动执行。
    """
    if credentials.credentials not in _tokens:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=error_body(40101, "Invalid or expired token."),
        )


def _read_password(prompt: str = "密  码: ") -> str:
    """
    安全读取密码输入。
    Windows 下回显 * 号（使用 msvcrt 逐字符读取），
    其他平台退回普通 input()。
    """
    try:
        import msvcrt                # Windows 专用模块

        sys.stdout.write(prompt)
        sys.stdout.flush()
        chars = []
        while True:
            ch = msvcrt.getch()      # 逐字符读取，不回显
            if ch in (b"\r", b"\n"):
                sys.stdout.write("\n")
                break
            elif ch == b"\x08":      # 退格键
                if chars:
                    chars.pop()
                    sys.stdout.write("\b \b")
            else:
                chars.append(ch.decode("utf-8", errors="ignore"))
                sys.stdout.write("*")     # 回显星号
            sys.stdout.flush()
        return "".join(chars).strip()
    except (ImportError, AttributeError):
        return input(prompt).strip()       # 非 Windows 回退


@app.on_event("startup")
def _startup_auth():
    """
    服务启动时弹出认证提示。
    用户名密码验证通过 → 生成 token 并启动服务。
    验证失败 → 拒绝启动（sys.exit(1)）。
    """
    print("\n" + "=" * 50)
    print("🔐 启动认证")
    print("=" * 50)

    # 读用户名
    username = ""
    while not username:
        username = input("用户名: ").strip()

    # 读密码（隐藏输入）
    password = ""
    while not password:
        password = _read_password()

    # 安全对比（恒定时间比较，防时序攻击）
    if not secrets.compare_digest(username, BASIC_USERNAME) or \
       not secrets.compare_digest(password, BASIC_PASSWORD):
        print("❌ 认证失败，服务拒绝启动。")
        sys.exit(1)

    # 认证通过，预生成一个启动 token 供后续使用
    startup_token = secrets.token_hex(32)
    _tokens[startup_token] = username

    print(f"✅ 认证成功，服务启动中...")
    print(f"Token: {startup_token}")
    print("=" * 50 + "\n")


# ============================================================================
# 十、API 路由
# ============================================================================

# ------ GET /health ------ 健康检查（无需认证） ------
@app.get("/health", summary="Health check", response_model=Dict[str, str])
def health() -> Dict[str, str]:
    return {"status": "ok"}


# ------ GET /tts/engines ------ 引擎列表（无需认证） ------
@app.get("/tts/engines", summary="List supported TTS engines")
def list_engines() -> Dict[str, Any]:
    engines = [
        EngineInfo(
            name=name,
            upstream_path=(
                "local (edge-tts)" if not url else urllib.parse.urlparse(url).path
            ),
        ).dict()
        for name, url in sorted(TTS_ENGINES.items())
    ]
    return {"engines": engines, "formats": sorted(SUPPORTED_FORMATS)}


# ------ POST /login ------ 登录拿 Token（无需认证） ------
@app.post("/login", summary="Login to get access token", response_model=LoginResponse)
def login(body: LoginRequest) -> LoginResponse:
    """
    用用户名密码换取 Bearer Token。
    拿到 token 后，调其他接口时放在 Authorization: Bearer <token> 头中。
    """
    if not secrets.compare_digest(body.username.encode(), BASIC_USERNAME.encode()) or \
       not secrets.compare_digest(body.password.encode(), BASIC_PASSWORD.encode()):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=error_body(40101, "Incorrect username or password."),
        )
    token = secrets.token_hex(32)         # 生成 64 位十六进制随机 token
    _tokens[token] = body.username        # 存入内存字典
    return LoginResponse(token=token)


# ------ POST /tts ------ TTS 合成（需要 Bearer Token） ------
@app.post(
    "/tts",
    summary="Unified TTS synthesis",
    responses={
        200: {"description": "Binary audio stream. In memory only."},
        401: {"model": ErrorResponse, "description": "Token 无效或过期"},
        422: {"model": ErrorResponse, "description": "请求参数不合法"},
        502: {"model": ErrorResponse, "description": "上游 TTS 服务异常"},
    },
)
def tts(
    payload: TTSRequest,                              # 请求体，Pydantic 自动校验
    _auth: None = Depends(verify_token),              # 依赖注入：校验 Bearer Token
) -> StreamingResponse:
    """
    统一 TTS 合成入口。

    流程：
    HTTP 请求 → Token 校验 → 引擎分流 → 合成音频 → StreamingResponse
                                              │
                          ┌───────────────────┼───────────────────┐
                          ▼                                       ▼
                  request_edge_tts()                      request_tts()
                  本地 MS Edge 引擎                        远端 TeleAI API
                  （免费，离线）                           （需 AppID/Key）
    """
    # 引擎分流
    if payload.engine == "edge":
        audio_bytes, audio_format, req_id = request_edge_tts(payload)
    else:
        audio_bytes, audio_format, req_id = request_tts(payload)

    # 确定 HTTP 响应头
    media_type, extension = media_type_for(audio_format)

    # 内存文件对象，不写磁盘
    audio_file = io.BytesIO(audio_bytes)
    headers = {
        "Content-Disposition": f'inline; filename="{req_id}.{extension}"',
        "X-Request-ID": req_id,
        "X-TTS-Engine": payload.engine,
        "Content-Length": str(len(audio_bytes)),
    }
    return StreamingResponse(audio_file, media_type=media_type, headers=headers)
