# -*- coding: utf-8 -*-
"""
TTS 服务完整测试脚本
用法：确认服务已启动后，在终端执行 python test_api.py
"""
import requests
import sys
import os

try:
    import msvcrt

    def _secure_input(prompt="密  码: "):
        sys.stdout.write(prompt)
        sys.stdout.flush()
        chars = []
        while True:
            ch = msvcrt.getch()
            if ch in (b"\r", b"\n"):
                sys.stdout.write("\n")
                break
            elif ch == b"\x08":
                if chars:
                    chars.pop()
                    sys.stdout.write("\b \b")
            else:
                chars.append(ch.decode("utf-8", errors="ignore"))
                sys.stdout.write("*")
            sys.stdout.flush()
        return "".join(chars)

except ImportError:
    _secure_input = input

BASE_URL = "http://127.0.0.1:8000"
OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))
PASS = 0
FAIL = 0

# ============================================================
# 1. 输入凭据并登录获取 Token
# ============================================================
print("=" * 60)
print("登录认证")
username = ""
while not username:
    username = input("用户名: ").strip()
password = ""
while not password:
    password = _secure_input("密  码: ").strip()
print()

print("正在登录获取 Token...")
resp = requests.post(
    f"{BASE_URL}/login",
    json={"username": username, "password": password},
    timeout=10,
)
if resp.status_code != 200:
    print(f"[FAIL] 登录失败: {resp.json()}")
    sys.exit(1)

token = resp.json()["token"]
TOKEN_HEADER = {"Authorization": f"Bearer {token}"}
print(f"[OK] 登录成功，Token: {token[:16]}...")
print("=" * 60)
print()



def test(name, method, path, expected_status, body=None, headers=None, save_as=None):
    global PASS, FAIL
    url = f"{BASE_URL}{path}"
    hdrs = {"Content-Type": "application/json"}
    hdrs.update(TOKEN_HEADER)
    if headers:
        hdrs.update(headers)

    try:
        if method == "GET":
            resp = requests.get(url, headers=hdrs, timeout=10)
        else:
            resp = requests.post(url, json=body, headers=hdrs, timeout=30)
    except Exception as e:
        print(f"[FAIL] {name}")
        print(f"       连接失败: {e}\n")
        FAIL += 1
        return None

    ok = resp.status_code == expected_status
    status_label = "PASS" if ok else "FAIL"
    if ok:
        PASS += 1
    else:
        FAIL += 1

    print(f"[{status_label}] {name}")
    print(f"       预期 {expected_status} → 实际 {resp.status_code}")

    if resp.status_code == 200 and save_as:
        filepath = os.path.join(OUTPUT_DIR, save_as)
        with open(filepath, "wb") as f:
            f.write(resp.content)
        print(f"       文件: {save_as} ({len(resp.content)} bytes)")

    if resp.status_code != 200:
        try:
            print(f"       返回: {resp.json()}")
        except Exception:
            print(f"       返回: {resp.text[:200]}")
    print()
    return resp


# ============================================================
# 测试开始
# ============================================================
print("=" * 60)
print("TTS 服务测试")
print(f"服务地址: {BASE_URL}")
print(f"当前用户: {username}")
print("=" * 60)
print()

# ---------- 测试1：健康检查 ----------
test("健康检查 GET /health",
     "GET", "/health", 200)

# ---------- 测试2：引擎列表 ----------
test("引擎列表 GET /tts/engines",
     "GET", "/tts/engines", 200)

# ---------- 测试3：Edge TTS 基础合成 ----------
test("Edge TTS 基础合成 (中文)",
     "POST", "/tts", 200,
     body={
         "input": "你好世界，欢迎使用TTS语音合成服务。",
         "engine": "edge",
         "voice": "zh-CN-XiaoxiaoNeural",
         "format": "MP3"
     },
     save_as="test_01_basic.mp3")

# ---------- 测试4：Edge TTS 欢快风格 ----------
test("Edge TTS 欢快风格 (cheerful + 加速)",
     "POST", "/tts", 200,
     body={
         "input": "今天真是太开心了，阳光明媚，万里无云！",
         "engine": "edge",
         "voice": "zh-CN-XiaoxiaoNeural",
         "format": "MP3",
         "style": "cheerful",
         "speed": 1.3,
         "pitch": "+10Hz",
         "volume": "+20%"
     },
     save_as="test_02_cheerful.mp3")

# ---------- 测试5：Edge TTS 悲伤风格 ----------
test("Edge TTS 悲伤风格 (sad + 减速)",
     "POST", "/tts", 200,
     body={
         "input": "今天的心情有些低落，天空也阴沉沉的。",
         "engine": "edge",
         "voice": "zh-CN-XiaoxiaoNeural",
         "format": "MP3",
         "style": "sad",
         "speed": 0.8,
         "pitch": "-10Hz",
         "volume": "-10%"
     },
     save_as="test_03_sad.mp3")

# ---------- 测试6：Edge TTS 普通风格 ----------
test("Edge TTS 默认风格 (general)",
     "POST", "/tts", 200,
     body={
         "input": "这是一段正常语速和语调的朗读。",
         "engine": "edge",
         "voice": "zh-CN-XiaoxiaoNeural",
         "format": "MP3",
         "style": "general",
         "speed": 1.0
     },
     save_as="test_04_general.mp3")

# ---------- 测试7：TeleAI 实时合成 ----------
test("TeleAI 实时合成 (supernatural)",
     "POST", "/tts", 200,
     body={
         "input": "你好，这是TeleAI实时语音合成测试。",
         "engine": "supernatural",
         "voice": "xianliaonv",
         "format": "MP3"
     },
     save_as="test_05_teleai.mp3")

# ---------- 测试8：参数校验 - speed 越界 ----------
test("参数校验: speed 越界 (5.0) → 422",
     "POST", "/tts", 422,
     body={"input": "hello", "engine": "edge", "speed": 5.0})

# ---------- 测试9：参数校验 - 缺少 text ----------
test("参数校验: 缺少必填字段 text → 422",
     "POST", "/tts", 422,
     body={"engine": "edge"})

# ============================================================
# 结果汇总
# ============================================================
print("=" * 60)
print(f"测试完成: {PASS} 通过, {FAIL} 失败, 共 {PASS + FAIL} 项")
print(f"音频文件输出目录: {OUTPUT_DIR}")
print("=" * 60)

if FAIL > 0:
    sys.exit(1)
