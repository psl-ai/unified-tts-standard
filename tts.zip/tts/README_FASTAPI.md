# TeleAI TTS 统一 FastAPI HTTP 接口

这个服务把现有 TeleAI TTS 调用统一成一个 HTTP 标准入口。上游鉴权仍然使用项目里的 AppID 和 Secret Key 自动签名；接口返回的音频文件只在内存中处理，不写入磁盘。

## 接口标准

| 项目 | 标准 |
|---|---|
| 健康检查 | `GET /health` |
| 引擎列表 | `GET /tts/engines` |
| TTS 合成 | `POST /tts` |
| 请求格式 | `Content-Type: application/json` |
| 调用方认证 | **Basic 认证**，默认用户名 `admin` / 密码 `tts123456`，可通过环境变量 `TTS_USERNAME` / `TTS_PASSWORD` 自定义 |
| 上游认证 | 服务端自动使用 AppID / Secret Key 生成签名 |
| 成功响应 | 二进制音频流，内存文件返回 |
| 失败响应 | 统一 JSON：`{"code": <int>, "message": "<str>", "details": <any>}` |

## 启动服务

```bash
cd D:\docker部署test\tts\tts
pip install -r requirements.txt

uvicorn app:app --host 0.0.0.0 --port 8000
uvicorn app:app --host 0.0.0.0 --port 8000
```

可选环境变量：

| 变量 | 默认值 | 说明 |
|---|---|---|
| `TTS_USERNAME` | `admin` | Basic 认证用户名 |
| `TTS_PASSWORD` | `tts123456` | Basic 认证密码 |
| `TTS_REQUEST_TIMEOUT` | `120` | 上游 TTS 请求超时时间，单位秒 |
| `TTS_VERIFY_TLS` | `false` | 是否校验上游 HTTPS 证书 |

## 健康检查

```http
GET /health
```

成功响应：

```json
{"status": "ok"}
```

## 查询支持的 TTS 引擎

```http
GET /tts/engines
```

成功响应：

```json
{
  "engines": [
    {"name": "offline", "upstream_path": "/aipaas/voice/v1/tts/offLineSynthesis"},
    {"name": "realtime", "upstream_path": "/aipaas/voice/v1/tts/supernatural"},
    {"name": "supernatural", "upstream_path": "/aipaas/voice/v1/tts/supernatural"}
  ],
  "formats": ["MP3"]
}
```

## 统一 TTS 合成

```http
POST /tts
Content-Type: application/json
Authorization: Basic base64(username:password)
```

使用 **Basic 认证**，默认用户名 `admin`、密码 `tts123456`。

### 请求体

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|---|---|---|---|---|
| `input` | string | 是 | 无 | 需要合成的文本 |
| `voice` | string | 否 | `zh-CN-XiaoxiaoNeural` | 音色名称 |
| `format` | string | 否 | `MP3` | 音频格式（统一 MP3 输出） |
| `engine` | string | 否 | `supernatural` | TTS 引擎：`supernatural` / `realtime` / `offline` |
| `req_id` | string | 否 | 自动生成 | 请求追踪 ID |
| `extra_params` | object | 否 | `{}` | 透传给上游 TTS 的额外参数 |

示例：

```json
{
  "input": "你好，这是一个统一的 TTS HTTP 接口。",
  "voice": "xianliaonv",
  "format": "MP3",
  "engine": "supernatural",
  "req_id": "test001",
  "extra_params": {}
}
```

### 成功响应

```http
HTTP/1.1 200 OK
Content-Type: audio/mpeg
Content-Disposition: inline; filename="test001.mp3"
Content-Length: <bytes>
X-Request-ID: test001
X-TTS-Engine: supernatural

<binary audio bytes>
```

所有输出统一为 MP3 格式，`Content-Type` 固定为 `audio/mpeg`。

### 失败响应

所有失败都返回统一 JSON：

```json
{
  "code": 42200,
  "message": "Invalid request body.",
  "details": []
}
```

常见错误码：

| HTTP | code | 说明 |
|---|---|---|
| 401 | `40101` | Basic 认证失败，用户名或密码错误 |
| 422 | `42200` | 请求体字段不合法 |
| 502 | `50201` | 连接上游 TTS 失败 |
| 502 | `50202` | 上游 TTS 返回非 200 状态 |
| 502 | `50203` | 上游响应没有合法的 `result.audio` |
| 502 | `50204` | 上游返回空音频 |

## curl 示例

```bash
# 第一步：登录获取 Token
curl -X POST http://127.0.0.1:8000/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"tts123456"}'

# 返回：{"token":"f89659fcc80643d3...","token_type":"bearer"}

# 第二步：用 Token 调 TTS 合成
curl -X POST http://127.0.0.1:8000/tts \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer f89659fcc80643d3..." \
  -d '{"input":"你好世界","engine":"edge"}' \
  -o output.mp3
```

## Java 调用示例

### 1. OkHttp（推荐）

```java
import okhttp3.*;
import java.io.*;

public class TtsClient {
    private static final String BASE_URL = "http://127.0.0.1:8000";
    private final OkHttpClient client = new OkHttpClient();
    private String token;

    // 第一步：登录拿 Token
    public void login(String username, String password) throws IOException {
        String json = String.format("{\"username\":\"%s\",\"password\":\"%s\"}", username, password);
        RequestBody body = RequestBody.create(json, MediaType.parse("application/json"));
        Request request = new Request.Builder()
                .url(BASE_URL + "/login")
                .post(body)
                .build();
        Response response = client.newCall(request).execute();
        // 解析 response.body().string() 拿到 token 字段
        this.token = parseToken(response.body().string());
        response.close();
    }

    // 第二步：调 TTS 合成语音
    public byte[] synthesize(String text, String engine) throws IOException {
        String json = String.format(
            "{\"input\":\"%s\",\"engine\":\"%s\"}", text, engine
        );
        RequestBody body = RequestBody.create(json, MediaType.parse("application/json"));
        Request request = new Request.Builder()
                .url(BASE_URL + "/tts")
                .post(body)
                .addHeader("Authorization", "Bearer " + token)
                .build();
        Response response = client.newCall(request).execute();
        byte[] audio = response.body().bytes();
        response.close();
        return audio;
    }

    // 保存为 MP3 文件
    public void saveToFile(byte[] audio, String path) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(path)) {
            fos.write(audio);
        }
    }
}
```

### 2. Spring RestTemplate

```java
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

RestTemplate rest = new RestTemplate();

// 登录
HttpHeaders loginHeaders = new HttpHeaders();
loginHeaders.setContentType(MediaType.APPLICATION_JSON);
String loginBody = "{\"username\":\"admin\",\"password\":\"tts123456\"}";
HttpEntity<String> loginReq = new HttpEntity<>(loginBody, loginHeaders);
Map<String, String> loginResp = rest.postForObject(
    "http://127.0.0.1:8000/login", loginReq, Map.class
);
String token = loginResp.get("token");

// TTS 合成
HttpHeaders ttsHeaders = new HttpHeaders();
ttsHeaders.setContentType(MediaType.APPLICATION_JSON);
ttsHeaders.setBearerAuth(token);
String ttsBody = "{\"input\":\"你好世界\",\"engine\":\"edge\"}";
HttpEntity<String> ttsReq = new HttpEntity<>(ttsBody, ttsHeaders);
byte[] audio = rest.postForObject(
    "http://127.0.0.1:8000/tts", ttsReq, byte[].class
);

// 保存文件
java.nio.file.Files.write(java.nio.file.Paths.get("output.mp3"), audio);
```

### 3. JDK 原生 HttpClient（Java 11+）

```java
import java.net.http.*;
import java.net.URI;

HttpClient client = HttpClient.newHttpClient();

// 登录
String loginJson = "{\"username\":\"admin\",\"password\":\"tts123456\"}";
HttpRequest loginReq = HttpRequest.newBuilder()
    .uri(URI.create("http://127.0.0.1:8000/login"))
    .header("Content-Type", "application/json")
    .POST(HttpRequest.BodyPublishers.ofString(loginJson))
    .build();
HttpResponse<String> loginResp = client.send(loginReq, HttpResponse.BodyHandlers.ofString());
// 解析 token...

// TTS 合成
String ttsJson = "{\"input\":\"你好世界\",\"engine\":\"edge\"}";
HttpRequest ttsReq = HttpRequest.newBuilder()
    .uri(URI.create("http://127.0.0.1:8000/tts"))
    .header("Content-Type", "application/json")
    .header("Authorization", "Bearer " + token)
    .POST(HttpRequest.BodyPublishers.ofString(ttsJson))
    .build();
HttpResponse<byte[]> ttsResp = client.send(ttsReq, HttpResponse.BodyHandlers.ofByteArray());
byte[] audio = ttsResp.body();
```
